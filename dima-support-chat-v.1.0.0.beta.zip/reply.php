<?php
session_start();
include 'includes/db.php';

if ($_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $chat_id = $_POST['chat_id'];
    $response = trim($_POST['response']);

    if (!empty($response)) {
        $stmt = $pdo->prepare("INSERT INTO chats (user_id, message, is_admin) VALUES ((SELECT user_id FROM chats WHERE id = :chat_id), :message, 1)");
        $stmt->execute(['chat_id' => $chat_id, 'message' => $response]);

        header("Location: admin.php");
        exit;
    }
}

$chat_id = $_GET['id'];
$stmt = $pdo->prepare("SELECT c.*, u.username FROM chats c JOIN users u ON c.user_id = u.id WHERE c.id = :id");
$stmt->execute(['id' => $chat_id]);
$chat = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پاسخ به پیام</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">پاسخ به پیام</h1>
        <form method="POST" class="col-md-6 mx-auto">
            <div class="mb-3">
                <label class="form-label">پیام مشتری:</label>
                <textarea class="form-control" readonly><?php echo htmlspecialchars($chat['message']); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="response" class="form-label">پاسخ شما:</label>
                <textarea name="response" id="response" class="form-control" required></textarea>
            </div>
            <input type="hidden" name="chat_id" value="<?php echo $chat_id; ?>">
            <button type="submit" class="btn btn-primary w-100">ارسال پاسخ</button>
        </form>
    </div>
</body>
</html>