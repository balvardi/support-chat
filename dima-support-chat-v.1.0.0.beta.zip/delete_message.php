<?php
session_start();
include 'includes/db.php';

if ($_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $chat_id = $_POST['chat_id'];

    $stmt = $pdo->prepare("DELETE FROM chats WHERE id = :id");
    $stmt->execute(['id' => $chat_id]);

    header("Location: admin.php");
    exit;
}
?>