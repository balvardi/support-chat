<?php
session_start();
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // اعتبارسنجی CSRF Token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'message' => 'درخواست نامعتبر است.']);
        exit;
    }

    $message = trim($_POST['message']);
    $user_id = $_SESSION['user_id'];

    if (!empty($message)) {
        $stmt = $pdo->prepare("INSERT INTO chats (user_id, message, is_admin) VALUES (:user_id, :message, 0)");
        $stmt->execute(['user_id' => $user_id, 'message' => $message]);

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'پیام نمی‌تواند خالی باشد.']);
    }
}
?>