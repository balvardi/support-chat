<?php
session_start();
include 'includes/db.php';

if ($_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// دریافت چت‌ها با Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$stmt = $pdo->prepare("SELECT c.*, u.username FROM chats c JOIN users u ON c.user_id = u.id ORDER BY c.created_at DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$chats = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت چت</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">پنل مدیریت چت</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>کاربر</th>
                    <th>پیام</th>
                    <th>تاریخ</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($chats as $chat): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($chat['username']); ?></td>
                        <td><?php echo htmlspecialchars($chat['message']); ?></td>
                        <td><?php echo $chat['created_at']; ?></td>
                        <td>
                            <a href="reply.php?id=<?php echo $chat['id']; ?>" class="btn btn-sm btn-primary">پاسخ</a>
                            <form method="POST" action="delete_message.php" style="display:inline;">
                                <input type="hidden" name="chat_id" value="<?php echo $chat['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <nav aria-label="Page navigation" class="mt-3">
            <ul class="pagination justify-content-center">
                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?>">قبلی</a>
                </li>
                <li class="page-item <?php echo count($chats) < $limit ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?>">بعدی</a>
                </li>
            </ul>
        </nav>
    </div>
</body>
</html>