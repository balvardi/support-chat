<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// دریافت چت‌ها با Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$stmt = $pdo->prepare("SELECT * FROM chats WHERE user_id = :user_id ORDER BY created_at ASC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$chats = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>چت پشتیبانی</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <style>
        .chat-box { height: 400px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; }
        .message-admin { color: blue; }
        .message-customer { color: green; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">چت پشتیبانی</h1>
        <div class="chat-box mb-3">
            <?php foreach ($chats as $chat): ?>
                <div class="<?php echo $chat['is_admin'] ? 'message-admin' : 'message-customer'; ?>">
                    <?php echo htmlspecialchars($chat['message']); ?>
                    <small class="d-block text-muted"><?php echo $chat['created_at']; ?></small>
                </div>
            <?php endforeach; ?>
        </div>
        <form id="chat-form">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="input-group">
                <input type="text" id="message" class="form-control" placeholder="پیام خود را بنویسید..." required>
                <button type="submit" class="btn btn-primary">ارسال</button>
            </div>
        </form>
        <nav aria-label="Page navigation" class="mt-3">
            <ul class="pagination justify-content-center">
                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?>">قبلی</a>
                </li>
                <li class="page-item <?php echo count($chats) < $limit ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?>">بعدی</a>
                </li>
            </ul>
        </nav>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#chat-form').on('submit', function(e) {
                e.preventDefault();
                const message = $('#message').val();
                const csrfToken = $('input[name="csrf_token"]').val();

                $.post('send_message.php', { message: message, csrf_token: csrfToken }, function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('خطا در ارسال پیام!');
                    }
                });
            });
        });
    </script>
</body>
</html>